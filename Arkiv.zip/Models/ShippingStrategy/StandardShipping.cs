﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PostalService.Models.ShippingStrategy
{
    public class StandardShipping : IShippingStrategy
    {
        public string ShippingType => "Standardfrakt";

        public int Priority => 2;

        public decimal BasePrice => 59m;
        public DateTime CalculateEstimatedDeliveryDate(DateTime sentDate) => sentDate.AddDays(3);
    }
}
